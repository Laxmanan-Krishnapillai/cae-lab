#!/bin/bash

chmod u+x *
export PATH=$(pwd):$PATH
